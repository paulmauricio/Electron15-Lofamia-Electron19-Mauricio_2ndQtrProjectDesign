/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class Team {
    
    private static String teamName;
    private static int energyPoints;
    private static Character teamCharacter1;
    private static Character teamCharacter2;
    
    public static void Team(String teamName, int energyPoints, Character teamCharacter1, Character teamCharacter2) {
        Team.setTeamName(teamName);
        Team.setEnergyPoints(energyPoints);
        Team.setTeamCharacter1(teamCharacter1);
        Team.setTeamCharacter2(teamCharacter2);
    }
    
    Team Team1 = new Team(team1, 5);
    Team Team2 = new Team(team2, 5);

    /**
     * @return the teamName
     */
    public static String getTeamName() {
        return teamName;
    }

    /**
     * @param aTeamName the teamName to set
     */
    public static void setTeamName(String aTeamName) {
        teamName = aTeamName;
    }

    /**
     * @return the energyPoints
     */
    public static int getEnergyPoints() {
        return energyPoints;
    }

    /**
     * @param aEnergyPoints the energyPoints to set
     */
    public static void setEnergyPoints(int aEnergyPoints) {
        energyPoints = aEnergyPoints;
    }

    /**
     * @return the teamCharacter1
     */
    public static Character getTeamCharacter1() {
        return teamCharacter1;
    }

    /**
     * @param aTeamCharacter1 the teamCharacter1 to set
     */
    public static void setTeamCharacter1(Character aTeamCharacter1) {
        teamCharacter1 = aTeamCharacter1;
    }

    /**
     * @return the teamCharacter2
     */
    public static Character getTeamCharacter2() {
        return teamCharacter2;
    }

    /**
     * @param aTeamCharacter2 the teamCharacter2 to set
     */
    public static void setTeamCharacter2(Character aTeamCharacter2) {
        teamCharacter2 = aTeamCharacter2;
    }

}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class AttackSkills extends Skills {
    
    public AttackSkills(String sn, String sd, Character user, Character tgt, int cost, int d) {
        super(sn, sd, user, tgt, cost);
        int damage = d;
        Character target = tgt;
    }
    
}

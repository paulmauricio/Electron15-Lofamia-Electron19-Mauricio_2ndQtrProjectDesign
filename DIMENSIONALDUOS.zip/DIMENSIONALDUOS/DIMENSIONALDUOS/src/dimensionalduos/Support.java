/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class Support extends Character{

    public Support(String n, String v, Class c, float hp, int def, int atk, Skills ass1, Skills ass2) {
        super(n, v, c, hp, def, atk, ass1, ass2);
    }

}

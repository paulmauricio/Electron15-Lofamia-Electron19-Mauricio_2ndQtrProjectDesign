/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class ConditionSkills extends Skills {
    
    public ConditionSkills(String sn, String sd, Character user, boolean tgt, int cost, int d, Condition c, Effect e) {
        super(sn, sd, user, tgt, cost);
        int damage = d;
        Condition condition = c;
        Effect effect = e;
        boolean target = tgt;
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dimensionalduos;
import java.util.Scanner;
/**
 *
 * @author bnsru
 */


public class DIMENSIONALDUOS {

    public static void main(String[] args) {
        

        // Create the characters
        Character Rhensis = new Character("Rhensis", "Real-life", Controller, 1500, 1500, 40, 50, totalInternalReflection, finalSlash);
        Character Paul = new Character("Paul", "Real-life", Assault, 1500, 1500, 40, 50, slinkySmash, slinkyStorm);
        Character Mercy = new Character("Mercy", "Overwatch", Support, 2000, 2000, 50, 20, caduceusStaff, resurrection);
        Character Batman = new Character("Batman", "DC", Tank, 2500, 2500, 60, 30, batarang, mechBatsuit);
                
        Scanner scan = new Scanner(System.in); 
        // Name Teams
        System.out.println("Name Team 1");
        Team.setTeamName(scan.nextLine());
        System.out.println("Name Team 2");
        Team.setTeamName(scan.nextLine());
        
        // Pick Characters
        Team.setTeam1Character1 = Paul;
        Team.setTeam1Character2 = Mercy;
        Team.setTeam2Character1 = Rhensis;
        Team.setTeam2Character2 = Batman;
   
        // Create the skills
        Skills slinkySmash = new AttackSkills("Slinky Smash", "Deals 200 damage", Paul, Rhensis, 2, 200);
        Skills slinkyStorm = new AttackSkills("Slinky Storm", "Deals 750 damage", Paul, Rhensis, 5, 750);
        Skills totalInternalReflection = new AttackSkills("Total Internal Reflection", "Deals 250 damage and heals 125 health to self", Rhensis, Paul, 3, 250);
        Skills finalSlash = new AttackSkills("Final Slash", "Deals 400 + 25% of lost health of target", Rhensis, Paul, 4, 400) {
            public boolean isConditionMet(Character target) {
                return target.getHealthPoints() < target.getMaxHealthPoints() * 0.3;
            }
        }, null);
        Skills batarang = new AttackSkills("Batarang", "Deals 75 damage", Batman, Mercy, 1, 75);
        Skills mechBatsuit = new SpecialSkills("Mech Batsuit", "Multiplies defense by 2", Batman, Batman, 6, 0, new Effect() {
            public void applyEffect(Character target) {
                target.setDefense(target.getDefense() * 2);
            }
        });
        Skills caduceusStaff = new HealingSkills("Caduceus Staff", "Heals 100 health", Mercy, Mercy 2, 0, 100);
        Skills resurrection = new SpecialSkills("Resurrection", "Revives a dead teammate", Mercy,  7, 0, new Effect() {
            public void applyEffect(Character target) {
                if (target.getHealthPoints() <= 0) {
                    target.setHealthPoints((float) (target.getMaxHealthPoints() * 0.5));
                }
            }
        });

        // Assign the skills to the characters
        paul.setAssignedSkills(slinkySmash);
        paul.addSkill(slinkyStorm);
        rhensis.setAssignedSkills(totalInternalReflection);
        rhensis.addSkill(finalSlash);
        batman.setAssignedSkills(batarang);
        batman.addSkill(mechBatsuit);
        mercy.setAssignedSkills(caduceusStaff);
        mercy.addSkill(resurrection);

        // Create the teams
        Team team1 = new Team("Team 1", 1000, new Character[]{batman, paul});
        Team team2 = new Team("Team 2", 1000, new Character[]{rhensis, mercy});

        // Game loop
        while (true) {
            System.out.println("Enter the index of the character you want to use (0-3): ");
            int characterIndex = scanner.nextInt();
            Character selectedCharacter = team1.getTeamCharacters()[characterIndex];

            // Check if the character can use a skill
            if (selectedCharacter.getEnergyPoints() >= selectedCharacter.getAssignedSkills().getCost()) {
                selectedCharacter.getAssignedSkills().useSkill(selectedCharacter);
            } else {
                System.out.println("Not enough energy points to use this skill.");
            }

            // Check if a team has won
            if (team1.getEnergyPoints() <= 0) {
                System.out.println("Team 2 wins!");
                break;
            } else if (team2.getEnergyPoints() <= 0) {
                System.out.println("Team 1 wins!");
                break;
            }
        }
    }

    private static Character createCharacter(String type) {
        switch (type.toLowerCase()) {
            case "batman":
                return new Tank("Batman", "DC", 1000, 50, 100, 5);
            case "paul":
                return new Assault("Paul", "DC", 1000, 50, 100, 5);
            case "rhensis":
                return new Controller("Rhensis", "DC", 1000, 50, 100, 5);
            case "mercy":
                return new Support("Mercy", "DC", 1000, 50, 100, 5);
            default:
                throw new IllegalArgumentException("Invalid character type: " + type);
        }
    }
}
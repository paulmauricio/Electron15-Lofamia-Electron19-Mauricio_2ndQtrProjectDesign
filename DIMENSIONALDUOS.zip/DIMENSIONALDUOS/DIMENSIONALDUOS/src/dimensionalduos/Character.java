package dimensionalduos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bnsru
 */
public class Character {

    private String characterName;
    private String characterVerse;
    private Class characterClass;
    private float healthPoints;
    private int defense;
    private int baseAttack;
    private Skills assignedSkills1;
    private Skills assignedSkills2;
    private int maxHealthPoints;
    
    public Character(String n, String v, Class c, int maxhp, float hp, int def, int atk, Skills ass1, Skills ass2) {
        this.characterName = n;
        this.characterVerse = v;
        this.characterClass = c;
        this.maxHealthPoints = maxhp;
        this.healthPoints = hp;
        this.defense = def;
        this.baseAttack = atk;
        this.assignedSkills1 = ass1;
        this.assignedSkills2 = ass2;
    }

    /**
     * @return the characterName
     */
    public String getCharacterName() {
        return characterName;
    }

    /**
     * @param characterName the characterName to set
     */
    public void setCharacterName(String characterName) {
        this.characterName = characterName;
    }

    /**
     * @return the characterVerse
     */
    public String getCharacterVerse() {
        return characterVerse;
    }

    /**
     * @param characterVerse the characterVerse to set
     */
    public void setCharacterVerse(String characterVerse) {
        this.characterVerse = characterVerse;
    }

    /**
     * @return the characterClass
     */
    public Class getCharacterClass() {
        return characterClass;
    }

    /**
     * @param characterClass the characterClass to set
     */
    public void setCharacterClass(Class characterClass) {
        this.characterClass = characterClass;
    }

    /**
     * @return the healthPoints
     */
    public float getHealthPoints() {
        return healthPoints;
    }

    /**
     * @param healthPoints the healthPoints to set
     */
    public void setHealthPoints(float healthPoints) {
        this.healthPoints = healthPoints;
    }

    /**
     * @return the defense
     */
    public int getDefense() {
        return defense;
    }

    /**
     * @param defense the defense to set
     */
    public void setDefense(int defense) {
        this.defense = defense;
    }

    /**
     * @return the baseAttack
     */
    public int getBaseAttack() {
        return baseAttack;
    }

    /**
     * @param baseAttack the baseAttack to set
     */
    public void setBaseAttack(int baseAttack) {
        this.baseAttack = baseAttack;
    }

    /**
     * @return the assignedSkills
     */
    public Skills getAssignedSkills() {
        return assignedSkills;
    }

    /**
     * @param assignedSkills the assignedSkills to set
     */
    public void setAssignedSkills(Skills assignedSkills) {
        this.assignedSkills = assignedSkills;
    }

    /**
     * @return the maxHealthPoints
     */
    public int getMaxHealthPoints() {
        return maxHealthPoints;
    }

    /**
     * @param maxHealthPoints the maxHealthPoints to set
     */
    public void setMaxHealthPoints(int maxHealthPoints) {
        this.maxHealthPoints = maxHealthPoints;
    }
}


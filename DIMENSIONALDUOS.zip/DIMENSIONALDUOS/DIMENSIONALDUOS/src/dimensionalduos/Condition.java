/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class Condition {
    // Conditions for each skill will be made here using if-else statements.
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class HealingSkills extends Skills {
    
    public HealingSkills(String sn, String sd, Character user, boolean tgt, int cost, int d, int heal, int shield) {
        super(sn, sd, user, tgt, cost);
        int healingAmount = heal;
        int shieldAmount = shield;
        boolean target = tgt;
    }

    private HealingSkills(String sn, String sd, Character user, boolean tgt, int cost) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

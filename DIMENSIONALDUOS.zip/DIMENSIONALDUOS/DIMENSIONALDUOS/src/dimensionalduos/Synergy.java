/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
class Synergy {
    private int additionalDef;
    private int additionalAttack;
    private int additionalHealthPoints;
    
    public Synergy(int addD, int addA, int addHP){
        this.additionalDef = addD;
        this.additionalAttack = addA;
        this.additionalHealthPoints = addHP;
    }
    
    
    Synergy attackSynergy = new Synergy(0, 100, 0);
    Synergy TankSynergy = new Synergy(50, 0, 500);
    Synergy ControllerSynergy = new Synergy(25, 50, 250);
    Synergy SupportSynergy = new Synergy(40, 25, 350);
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class Skills {

    private String skillName;
    private String skillDescription;
    private int energyCost;
    private boolean target;
    private Character user;
    
    // Note: SkillSymbol should be here too but the variable container for images haven't been discussed yet.
    public Skills(String sn, String sd, Character user, int cost, Character tgt) {
    this.skillName = sn;
    this.skillDescription = sd;
    this.user = user;
    this.target = tgt;
    this.energyCost = cost;
    }
}

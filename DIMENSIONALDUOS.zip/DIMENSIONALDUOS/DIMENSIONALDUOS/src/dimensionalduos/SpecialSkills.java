/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dimensionalduos;

/**
 *
 * @author bnsru
 */
public class SpecialSkills extends Skills {
    
    public SpecialSkills(String sn, String sd, Character user, boolean tgt, int cost, int d, Effect e) {
        super(sn, sd, user, tgt, cost);
        int damage = d;
        Effect effect = e;
        boolean target = tgt;
    }

    private SpecialSkills(String sn, String sd, Character user, boolean tgt, int cost) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
